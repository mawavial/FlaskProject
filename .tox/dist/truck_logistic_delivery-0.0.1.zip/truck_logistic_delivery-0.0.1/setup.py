import setuptools

setuptools.setup(
    name="truck_logistic_delivery",
    version="0.0.1",
    author="mateus",
    descripton="A small application to manage trucks and drivers",
    requires_dist=['flask']
)
